SELECT COUNT(DISTINCT C.Category)
FROM Category C, Bid B
WHERE C.Item = B.Item AND B.Amount > 100;
