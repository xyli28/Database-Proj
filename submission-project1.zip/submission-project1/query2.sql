SELECT COUNT(UserID) FROM AuctionUser WHERE Location="New York";
